package com.instagrp.matrimony.bright_weddings

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
