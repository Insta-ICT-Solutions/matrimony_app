final String baseUrl = "http://localhost:8000/";



/**** AUTH URLs  ****/

final String registerUrl = "auth/register";

final String loginUrl = "auth/login";


final String forgotPasswordUrl = "auth/forgot-password";


final String verifyOtp = "auth/verify-otp";


final String newRegistration = "clients/register";

