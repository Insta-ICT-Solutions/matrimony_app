var bloodGroups = <String>[
  "A+ve",
  "B+ve",
  "AB+ve",
  "O+ve",
  "A-ve",
  "B-ve",
  "AB-ve",
  "O-ve",
];

var gender = <String>[
  'Male',
  'Female'
];