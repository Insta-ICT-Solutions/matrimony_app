
/******** SVG Paths ********/
final String loginCouple = "assets/svg/loginCouple.svg";
final String whatsapp = "assets/svg/whatsapp.svg";
final String twitter = "assets/svg/twitter.svg";
final String facebook = "assets/svg/facebook.svg";
final String youtube = "assets/svg/youtube.svg";



/******** Image Paths ********/
final String loginCouplePNG = "assets/images/loginCouple.png";