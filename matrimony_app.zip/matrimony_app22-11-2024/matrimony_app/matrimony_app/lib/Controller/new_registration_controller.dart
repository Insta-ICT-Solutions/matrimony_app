
import 'package:bright_weddings/Helper/size_config.dart';
import 'package:bright_weddings/Models/NewRegistrationModel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:popover/popover.dart';
import 'package:intl/intl.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../Constants/app_constants.dart';
import '../View/Dashboard/dashboard.dart';

class NewRegistrationController extends GetxController {
  // Step 1: Basic Information
  final TextEditingController nameController = TextEditingController();
  final TextEditingController castController = TextEditingController();
  final TextEditingController subCastController = TextEditingController();
  final TextEditingController devakController = TextEditingController();
  final TextEditingController rasController = TextEditingController();
  final TextEditingController ganController = TextEditingController();

  // Step 2: Contact and Education
  final TextEditingController addressController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController emailIDController = TextEditingController();
  final TextEditingController educationController = TextEditingController();
  final TextEditingController jobController = TextEditingController();

  // Step 3: Additional Details
  final TextEditingController demandController = TextEditingController();

  var selectedBloodGroup = "A+ve".obs;
  var selectedGender = "male".obs;
  var selectedMarriage = "First".obs;
  var selectedFile = Rxn<PlatformFile>();
  var selectedFileName = "Upload Photo".obs;
  var selectedDate = Rxn<DateTime>();
  var formattedDate = 'Select Date'.obs;
  var selectedFileUnicode = ''.obs;

  // Navigation management
  var currentFormIndex = 0.obs;

  // Dropdown values
  var bloodGroups = <String>["A+", "B+", "AB+", "O+", "A-", "B-", "AB-", "O-"];
  var gender = <String>["male", "female"];
  var marriagestatus = <String>["first", "second"];

  // Navigate to the next step
  void goToNextStep() {
    if (currentFormIndex.value < 2) {
      currentFormIndex.value++;
    }
  }

  // Navigate to the previous step
  void goToPreviousStep() {
    if (currentFormIndex.value > 0) {
      currentFormIndex.value--;
    }
  }

  // Show popups for dropdown selection
  void showPopUpMarriage(BuildContext context) {
    showPopover(
      direction: PopoverDirection.right,
      height: marriagestatus.length * 50.0,
      width: 20.0.w,
      context: context,
      bodyBuilder: (context) {
        return ListView.builder(
          itemCount: marriagestatus.length,
          itemBuilder: (context, index) {
            return ListTile(
              onTap: () {
                selectedMarriage.value = marriagestatus[index];
                Navigator.pop(context);
              },
              title: Text(marriagestatus[index]),
            );
          },
        );
      },
    );
  }

  void showPopUpGender(BuildContext context) {
    showPopover(
      direction: PopoverDirection.right,
      height: gender.length * 50.0,
      width: 25.0.w,
      context: context,
      bodyBuilder: (context) {
        return ListView.builder(
          itemCount: gender.length,
          itemBuilder: (context, index) {
            return ListTile(
              onTap: () {
                selectedGender.value = gender[index];
                Navigator.pop(context);
              },
              title: Text(gender[index]),
            );
          },
        );
      },
    );
  }

  void showPopUp(BuildContext context) {
    showPopover(
      direction: PopoverDirection.right,
      height: 17.0.h,
      width: 20.0.w,
      context: context,
      bodyBuilder: (context) {
        return ListView.builder(
          itemCount: bloodGroups.length,
          itemBuilder: (context, index) {
            return ListTile(
              onTap: () {
                selectedBloodGroup.value = bloodGroups[index];
                Navigator.pop(context);
              },
              title: Text(bloodGroups[index]),
            );
          },
        );
      },
    );
  }

  // File picker and image handling
  Future<void> pickFile(FileType fileType) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: fileType,
        allowMultiple: false,
      );

      if (result != null) {
        selectedFile.value = result.files.first;
        selectedFileName.value = selectedFile.value!.name;
        if (fileType == FileType.image) {
          Uint8List? fileBytes;
          if (selectedFile.value!.bytes != null) {
            fileBytes = selectedFile.value!.bytes;
          } else if (selectedFile.value!.path != null) {
            File file = File(selectedFile.value!.path!);
            fileBytes = await file.readAsBytes();
          }
          if (fileBytes != null) {
            String base64String = base64Encode(fileBytes);
            selectedFileUnicode.value = base64String;
          } else {
            selectedFileUnicode.value = '';
          }
        } else {
          selectedFileUnicode.value = '';
        }
      } else {
        print('File selection canceled.');
      }
    } catch (e) {
      print('Error picking file: $e');
    }
  }


  // Date picker
  Future<void> pickDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate.value ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );

    if (pickedDate != null) {
      selectedDate.value = pickedDate;
      formattedDate.value = DateFormat('dd-MM-yyyy').format(pickedDate);
      print('Selected date: ${formattedDate.value}');
    } else {
      print('Date selection canceled.');
    }
  }


  Future<bool> submitFormData() async {

    final SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    final String token = sharedPreferences.getString('token') ?? "";

    // Create the request model
    final ClientRegistrationModel request = ClientRegistrationModel(
      id: "1",
      userName: nameController.text.trim(),
      cast: castController.text.trim(),
      subCast: subCastController.text.trim(),
      devak: devakController.text.trim(),
      ras: rasController.text.trim(),
      gan: ganController.text.trim(),
      address: addressController.text.trim(),
      phoneNumber: phoneController.text.trim(),
      email: emailIDController.text.trim(),
      education: educationController.text.trim(),
      job: jobController.text.trim(),
      demands: demandController.text.trim(),
      bloodGroup: selectedBloodGroup.value.trim(),
      gender: selectedGender.value.trim(),
      marragestatus: selectedMarriage.value.trim(),
      profilePictureUrl: selectedFileUnicode.value,
      birthDate: formattedDate.value.trim(),
    );

    // Send the request
    try {
      final response = await http.post(
        Uri.parse(baseUrl + newRegistration),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token",
        },
        body: jsonEncode(request.toJson()),
      );

      print("Response Code: ${response.statusCode}");
      print("Response Body: ${response.body}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        print(jsonDecode(response.body)['message']);

        Get.to(() => Dashboard());
        return true;
      } else {
        print("Error: ${response.statusCode} - ${response.reasonPhrase}");
        return false;
      }
    } catch (e) {
      print("Network Error: $e");
      return false;
    }
  }

}