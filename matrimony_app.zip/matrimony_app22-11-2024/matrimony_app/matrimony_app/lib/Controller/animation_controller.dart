import 'package:get/get.dart';

class AnimationController extends GetxController{

}